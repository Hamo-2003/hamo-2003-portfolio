import React, { createContext, useContext, useState, useEffect } from "react";

type Language = "ar" | "en";

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

const translations: Record<Language, Record<string, string>> = {
  ar: {
    // Navigation
    "nav.about": "من أنا",
    "nav.skills": "المهارات",
    "nav.tools": "الأدوات",
    
    // Hero Section
    "hero.title": "محمد صبحي",
    "hero.subtitle": "مهندس زراعي متخصص في تطوير الأدوات والحلول الزراعية الذكية",
    "hero.contact": "تواصل معي",
    "hero.projects": "عرض المشاريع",
    
    // About Section
    "about.title": "من أنا",
    "about.description1": "أنا مهندس زراعي متخصص في تطوير الحلول التكنولوجية للقطاع الزراعي. أعمل على إنشاء أدوات عملية وفعالة تساعد المزارعين والمتخصصين في تحسين إنتاجيتهم.",
    "about.description2": "تركز خبرتي على التسميد الدقيق وإدارة الموارد الزراعية بكفاءة، مع استخدام أحدث التقنيات في تطوير الويب والتطبيقات.",
    "about.education": "التعليم",
    "about.education_desc": "هندسة زراعية",
    "about.development": "التطوير",
    "about.development_desc": "ويب وتطبيقات",
    "about.specialty": "التخصص",
    "about.specialty_desc": "الزراعة الذكية",
    "about.innovation": "الابتكار",
    "about.innovation_desc": "حلول مبتكرة",
    
    // Skills Section
    "skills.title": "المهارات",
    "skills.web": "تطوير الويب",
    "skills.web_desc": "React, TypeScript, Tailwind CSS، وتطوير تطبيقات ويب حديثة وسريعة الاستجابة",
    "skills.agriculture": "الزراعة الدقيقة",
    "skills.agriculture_desc": "حسابات التسميد، إدارة الموارد المائية، والتخطيط الزراعي المتقدم",
    "skills.tools": "تطوير الأدوات",
    "skills.tools_desc": "إنشاء حاسبات وأدوات متخصصة تلبي احتياجات القطاع الزراعي",
    
    // Tools Section
    "tools.title": "أدواتي",
    "tools.calculator_name": "أداة حساب الأسمدة",
    "tools.calculator_desc": "حاسبة متقدمة لحساب وحدات العناصر الغذائية في الأسمدة",
    "tools.wa_name": "مولد روابط واتساب",
    "tools.wa_desc": "أداة احترافية لإنشاء روابط واتساب من ملفات Excel و Word",
    "tools.use": "استخدم الأداة",
    
    // Contact Section
    "contact.title": "تواصل معي",
    
    // Footer
    "footer.copyright": "© 2025 محمد صبحي | جميع الحقوق محفوظة",
    
    // Fertilizer Calculator
    "calc.title": "حاسبة وحدات العناصر من الأسمدة",
    "calc.back": "العودة للرئيسية",
    "calc.select_lang": "اختر اللغة",
    "calc.arabic": "العربية",
    "calc.english": "English",
    "calc.select_fertilizer": "اختر السماد:",
    "calc.enter_units": "أدخل عدد الوحدات المطلوبة:",
    "calc.calculate": "حساب",
    "calc.export_csv": "تصدير CSV",
    "calc.export_excel": "تصدير Excel",
    "calc.print": "طباعة",
    "calc.error_units": "الرجاء إدخال عدد الوحدات",
    "calc.error_data": "خطأ: لم يتم العثور على بيانات السماد",
    "calc.result": "تحتاج إلى {kg} كجم من سماد {fert}",
    "calc.designed_by": "⚡ تصميم م. محمد صبحي ⚡",
  },
  en: {
    // Navigation
    "nav.about": "About",
    "nav.skills": "Skills",
    "nav.tools": "Tools",
    
    // Hero Section
    "hero.title": "Mohamed Sobhy",
    "hero.subtitle": "Agricultural Engineer specialized in developing smart agricultural tools and solutions",
    "hero.contact": "Contact Me",
    "hero.projects": "View Projects",
    
    // About Section
    "about.title": "About Me",
    "about.description1": "I am an agricultural engineer specialized in developing technological solutions for the agricultural sector. I work on creating practical and effective tools that help farmers and specialists improve their productivity.",
    "about.description2": "My expertise focuses on precision fertilization and efficient agricultural resource management, using the latest technologies in web and application development.",
    "about.education": "Education",
    "about.education_desc": "Agricultural Engineering",
    "about.development": "Development",
    "about.development_desc": "Web & Applications",
    "about.specialty": "Specialty",
    "about.specialty_desc": "Smart Agriculture",
    "about.innovation": "Innovation",
    "about.innovation_desc": "Innovative Solutions",
    
    // Skills Section
    "skills.title": "Skills",
    "skills.web": "Web Development",
    "skills.web_desc": "React, TypeScript, Tailwind CSS, and developing modern responsive web applications",
    "skills.agriculture": "Precision Agriculture",
    "skills.agriculture_desc": "Fertilization calculations, water resource management, and advanced agricultural planning",
    "skills.tools": "Tool Development",
    "skills.tools_desc": "Creating specialized calculators and tools that meet agricultural sector needs",
    
    // Tools Section
    "tools.title": "My Tools",
    "tools.calculator_name": "Fertilizer Calculator",
    "tools.calculator_desc": "Advanced calculator for calculating nutrient units in fertilizers",
    "tools.wa_name": "WhatsApp Link Generator",
    "tools.wa_desc": "Professional tool for creating WhatsApp links from Excel and Word files",
    "tools.use": "Use Tool",
    
    // Contact Section
    "contact.title": "Contact Me",
    
    // Footer
    "footer.copyright": "© 2025 Mohamed Sobhy | All Rights Reserved",
    
    // Fertilizer Calculator
    "calc.title": "Fertilizer Nutrient Unit Calculator",
    "calc.back": "Back to Home",
    "calc.select_lang": "Select Language",
    "calc.arabic": "العربية",
    "calc.english": "English",
    "calc.select_fertilizer": "Select fertilizer:",
    "calc.enter_units": "Enter required units:",
    "calc.calculate": "Calculate",
    "calc.export_csv": "Export CSV",
    "calc.export_excel": "Export Excel",
    "calc.print": "Print",
    "calc.error_units": "Please enter units",
    "calc.error_data": "Error: Fertilizer data not found",
    "calc.result": "You need {kg} kg of {fert} fertilizer",
    "calc.designed_by": "⚡ Created by ENG. Mohamed Sobhy ⚡",
  }
};

export function LanguageProvider({ children }: { children: React.ReactNode }) {
  const [language, setLanguageState] = useState<Language>("ar");

  useEffect(() => {
    const savedLanguage = (localStorage.getItem("language") as Language) || "ar";
    setLanguageState(savedLanguage);
    updateDocumentLanguage(savedLanguage);
  }, []);

  const updateDocumentLanguage = (lang: Language) => {
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === "ar" ? "rtl" : "ltr";
    document.body.dir = lang === "ar" ? "rtl" : "ltr";
  };

  const setLanguage = (lang: Language) => {
    setLanguageState(lang);
    localStorage.setItem("language", lang);
    updateDocumentLanguage(lang);
  };

  const t = (key: string): string => {
    return translations[language][key] || key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error("useLanguage must be used within LanguageProvider");
  }
  return context;
}
