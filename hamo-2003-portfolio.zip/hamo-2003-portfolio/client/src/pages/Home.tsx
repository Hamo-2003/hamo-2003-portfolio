import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ExternalLink, Github, Mail, Linkedin, Code2, Zap } from "lucide-react";
import { useLanguage } from "@/contexts/LanguageContext";

export default function Home() {
  const { language, setLanguage, t } = useLanguage();

  const tools = [
    {
      nameKey: "tools.calculator_name",
      descKey: "tools.calculator_desc",
      url: "/tools/fertilizer-calculator",
      icon: "🌾",
      color: "from-green-500 to-emerald-600"
    },
    {
      nameKey: "tools.wa_name",
      descKey: "tools.wa_desc",
      url: "https://hamo-2003.github.io/WA-Tool-Pro/",
      icon: "💬",
      color: "from-blue-500 to-cyan-600",
      external: true
    }
  ];

  return (
    <div className={`min-h-screen flex flex-col bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 text-white ${language === "ar" ? "rtl" : "ltr"}`}>
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-slate-900/80 backdrop-blur-md border-b border-slate-700">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
          <div className="flex gap-6 items-center">
            <a href="#about" className="hover:text-cyan-400 transition-colors">{t("nav.about")}</a>
            <a href="#skills" className="hover:text-cyan-400 transition-colors">{t("nav.skills")}</a>
            <a href="#tools" className="hover:text-cyan-400 transition-colors">{t("nav.tools")}</a>
            <div className={`flex gap-2 ${language === "ar" ? "mr-4 pr-4 border-r" : "ml-4 pl-4 border-l"} border-slate-700`}>
              <button
                onClick={() => setLanguage("ar")}
                className={`px-3 py-1 rounded text-sm font-semibold transition-colors ${
                  language === "ar"
                    ? "bg-blue-500 text-white"
                    : "bg-slate-700 text-slate-300 hover:bg-slate-600"
                }`}
              >
                العربية
              </button>
              <button
                onClick={() => setLanguage("en")}
                className={`px-3 py-1 rounded text-sm font-semibold transition-colors ${
                  language === "en"
                    ? "bg-blue-500 text-white"
                    : "bg-slate-700 text-slate-300 hover:bg-slate-600"
                }`}
              >
                EN
              </button>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative flex-1 flex items-center justify-center px-4 py-20 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-500/10 to-cyan-500/10 blur-3xl"></div>
        <div className="relative z-10 text-center max-w-3xl">
          <h1 className="text-5xl md:text-7xl font-bold mb-6 bg-gradient-to-r from-blue-400 via-cyan-400 to-emerald-400 bg-clip-text text-transparent">
            {t("hero.title")}
          </h1>
          <p className="text-xl md:text-2xl text-slate-300 mb-8">
            {t("hero.subtitle")}
          </p>
          <div className="flex gap-4 justify-center flex-wrap">
            <Button className="bg-blue-500 hover:bg-blue-600 text-white px-8 py-6 text-lg">
              {t("hero.contact")}
            </Button>
            <Button variant="outline" className="border-cyan-400 text-cyan-400 hover:bg-cyan-400/10 px-8 py-6 text-lg">
              {t("hero.projects")}
            </Button>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-20 px-4 bg-slate-800/50">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-4xl font-bold mb-12 text-center bg-gradient-to-r from-blue-400 to-cyan-400 bg-clip-text text-transparent">
            {t("about.title")}
          </h2>
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div className="space-y-4 text-slate-300 leading-relaxed">
              <p>{t("about.description1")}</p>
              <p>{t("about.description2")}</p>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <Card className="bg-gradient-to-br from-blue-500/20 to-blue-600/20 border-blue-400/30 p-6 text-center">
                <div className="text-3xl mb-2">📚</div>
                <p className="font-semibold">{t("about.education")}</p>
                <p className="text-sm text-slate-400">{t("about.education_desc")}</p>
              </Card>
              <Card className="bg-gradient-to-br from-cyan-500/20 to-cyan-600/20 border-cyan-400/30 p-6 text-center">
                <div className="text-3xl mb-2">💻</div>
                <p className="font-semibold">{t("about.development")}</p>
                <p className="text-sm text-slate-400">{t("about.development_desc")}</p>
              </Card>
              <Card className="bg-gradient-to-br from-emerald-500/20 to-emerald-600/20 border-emerald-400/30 p-6 text-center">
                <div className="text-3xl mb-2">🌾</div>
                <p className="font-semibold">{t("about.specialty")}</p>
                <p className="text-sm text-slate-400">{t("about.specialty_desc")}</p>
              </Card>
              <Card className="bg-gradient-to-br from-purple-500/20 to-purple-600/20 border-purple-400/30 p-6 text-center">
                <div className="text-3xl mb-2">⚡</div>
                <p className="font-semibold">{t("about.innovation")}</p>
                <p className="text-sm text-slate-400">{t("about.innovation_desc")}</p>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Skills Section */}
      <section id="skills" className="py-20 px-4">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-4xl font-bold mb-12 text-center bg-gradient-to-r from-blue-400 to-cyan-400 bg-clip-text text-transparent">
            {t("skills.title")}
          </h2>
          <div className="grid md:grid-cols-3 gap-8">
            <Card className="bg-slate-800 border-slate-700 p-8 hover:border-blue-400 transition-colors">
              <Code2 className="w-12 h-12 mb-4 text-blue-400" />
              <h3 className="text-xl font-bold mb-4">{t("skills.web")}</h3>
              <p className="text-slate-400">{t("skills.web_desc")}</p>
            </Card>
            <Card className="bg-slate-800 border-slate-700 p-8 hover:border-cyan-400 transition-colors">
              <Zap className="w-12 h-12 mb-4 text-cyan-400" />
              <h3 className="text-xl font-bold mb-4">{t("skills.agriculture")}</h3>
              <p className="text-slate-400">{t("skills.agriculture_desc")}</p>
            </Card>
            <Card className="bg-slate-800 border-slate-700 p-8 hover:border-emerald-400 transition-colors">
              <Code2 className="w-12 h-12 mb-4 text-emerald-400" />
              <h3 className="text-xl font-bold mb-4">{t("skills.tools")}</h3>
              <p className="text-slate-400">{t("skills.tools_desc")}</p>
            </Card>
          </div>
        </div>
      </section>

      {/* Tools Section */}
      <section id="tools" className="py-20 px-4 bg-slate-800/50">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-bold mb-12 text-center bg-gradient-to-r from-blue-400 to-cyan-400 bg-clip-text text-transparent">
            {t("tools.title")}
          </h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {tools.map((tool, idx) => (
              <Card key={idx} className="bg-gradient-to-br from-slate-800 to-slate-900 border-slate-700 overflow-hidden hover:border-cyan-400 transition-all hover:shadow-lg hover:shadow-cyan-500/20">
                <div className={`h-32 bg-gradient-to-br ${tool.color} flex items-center justify-center text-6xl`}>
                  {tool.icon}
                </div>
                <div className="p-6">
                  <h3 className="text-xl font-bold mb-2">{t(tool.nameKey)}</h3>
                  <p className="text-slate-400 mb-6">{t(tool.descKey)}</p>
                  {tool.external ? (
                    <a href={tool.url} target="_blank" rel="noopener noreferrer">
                      <Button className="w-full bg-gradient-to-r from-blue-500 to-cyan-500 hover:from-blue-600 hover:to-cyan-600 text-white flex items-center justify-center gap-2">
                        {t("tools.use")}
                        <ExternalLink className="w-4 h-4" />
                      </Button>
                    </a>
                  ) : (
                    <a href={tool.url}>
                      <Button className="w-full bg-gradient-to-r from-blue-500 to-cyan-500 hover:from-blue-600 hover:to-cyan-600 text-white flex items-center justify-center gap-2">
                        {t("tools.use")}
                        <ExternalLink className="w-4 h-4" />
                      </Button>
                    </a>
                  )}
                </div>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section className="py-20 px-4 bg-gradient-to-t from-slate-900 to-transparent">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-4xl font-bold mb-12 bg-gradient-to-r from-blue-400 to-cyan-400 bg-clip-text text-transparent">
            {t("contact.title")}
          </h2>
          <div className="flex gap-6 justify-center flex-wrap mb-12">
            <a href="https://github.com/hamo-2003" target="_blank" rel="noopener noreferrer" className="p-4 bg-slate-800 hover:bg-slate-700 rounded-lg transition-colors">
              <Github className="w-6 h-6" />
            </a>
            <a href="mailto:hamo@example.com" className="p-4 bg-slate-800 hover:bg-slate-700 rounded-lg transition-colors">
              <Mail className="w-6 h-6" />
            </a>
            <a href="https://linkedin.com" target="_blank" rel="noopener noreferrer" className="p-4 bg-slate-800 hover:bg-slate-700 rounded-lg transition-colors">
              <Linkedin className="w-6 h-6" />
            </a>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-slate-700 py-8 px-4 text-center text-slate-400">
        <p>{t("footer.copyright")}</p>
      </footer>
    </div>
  );
}
