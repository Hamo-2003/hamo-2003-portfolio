import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ArrowLeft } from "lucide-react";
import { useLocation } from "wouter";
import { useLanguage } from "@/contexts/LanguageContext";

const FERTILIZERS_DATA = [
  { en: "Urea 46% N", ar: "يوريا 46% ن", ratios: { N: 46 } },
  { en: "Ammonium Nitrate 33.5% N", ar: "نترات الأمونيوم 33.5% ن", ratios: { N: 33.5 } },
  { en: "Ammonium Sulfate 20.5% N", ar: "كبريتات الأمونيوم 20.5% ن", ratios: { N: 20.5 } },
  { en: "Calcium Nitrate 15.5% N", ar: "نترات الكالسيوم 15.5% ن", ratios: { N: 15.5 } },
  { en: "Nitric Acid 60% N", ar: "حمض النيتريك 60% ن", ratios: { N: 60 } },
  { en: "MAP 12-61-0", ar: "فوسفات أحادي الأمونيوم 12-61-0", ratios: { N: 12, P: 61 } },
  { en: "DAP 18-46-0", ar: "فوسفات ثنائي الأمونيوم 18-46-0", ratios: { N: 18, P: 46 } },
  { en: "MKP 0-52-34", ar: "فوسفات أحادي البوتاسيوم 0-52-34", ratios: { P: 52, K: 34 } },
  { en: "NPK 20-20-20", ar: "مركب 20-20-20", ratios: { N: 20, P: 20, K: 20 } },
  { en: "Urea Phosphate 17-44-0", ar: "فوسفات اليوريا 17-44-0", ratios: { N: 17, P: 44 } },
  { en: "Mono-Ammonium Phosphate 12-51.5-0", ar: "فوسفات أحادي الأمونيوم 12-51.5-0", ratios: { N: 12, P: 51.5 } },
  { en: "Di-Ammonium Phosphate 19.5-55-0", ar: "فوسفات ثنائي الأمونيوم 19.5-55-0", ratios: { N: 19.5, P: 55 } },
  { en: "Single Super Phosphate 0-15.5-0", ar: "سوبر فوسفات أحادي 0-15.5-0", ratios: { P: 15.5 } },
  { en: "Triple Super Phosphate 0-46-0", ar: "سوبر فوسفات ثلاثي 0-46-0", ratios: { P: 46 } },
  { en: "Phosphoric Acid 85% P", ar: "حمض الفوسفوريك 85% ف", ratios: { P: 85 } },
  { en: "Potassium Sulfate 0-0-48", ar: "كبريتات البوتاسيوم 0-0-48", ratios: { K: 48 } },
  { en: "Potassium Chloride 0-0-61", ar: "كلوريد البوتاسيوم 0-0-61", ratios: { K: 61 } },
  { en: "Potassium Nitrate 13-0-44", ar: "نترات البوتاسيوم 13-0-44", ratios: { N: 13, K: 44 } }
];

export default function FertilizerCalculator() {
  const [, navigate] = useLocation();
  const { language, setLanguage, t } = useLanguage();
  const [selectedFertilizer, setSelectedFertilizer] = useState(FERTILIZERS_DATA[0].en);
  const [units, setUnits] = useState<number | string>("");
  const [result, setResult] = useState<string>("");

  const getFertilizerRatios = (name: string) => {
    const fert = FERTILIZERS_DATA.find(f => f.en === name);
    return fert ? fert.ratios : null;
  };

  const getFertilizerDisplay = (name: string) => {
    const fert = FERTILIZERS_DATA.find(f => f.en === name);
    return fert ? (language === "ar" ? fert.ar : fert.en) : name;
  };

  const calculate = () => {
    if (!units || units === "") {
      setResult(t("calc.error_units"));
      return;
    }

    const ratios = getFertilizerRatios(selectedFertilizer);
    if (!ratios) {
      setResult(t("calc.error_data"));
      return;
    }

    const percent = Object.values(ratios)[0];
    const kg = (Number(units) / (percent / 100)).toFixed(2);
    const fertDisplay = getFertilizerDisplay(selectedFertilizer);

    const resultText = language === "ar"
      ? `تحتاج إلى ${kg} كجم من سماد ${fertDisplay}`
      : `You need ${kg} kg of ${fertDisplay} fertilizer`;
    
    setResult(resultText);
  };

  const downloadCSV = () => {
    if (!result) return;
    const blob = new Blob([result], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "fertilizer_result.csv";
    a.click();
  };

  const downloadExcel = () => {
    if (!result) return;
    const blob = new Blob([result], { type: "application/vnd.ms-excel" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "fertilizer_result.xls";
    a.click();
  };

  return (
    <div className={`min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 text-white p-4 ${language === "ar" ? "rtl" : "ltr"}`}>
      {/* Header */}
      <div className="max-w-4xl mx-auto mb-8">
        <button
          onClick={() => navigate("/")}
          className="flex items-center gap-2 text-cyan-400 hover:text-cyan-300 transition-colors mb-6"
        >
          <ArrowLeft className="w-5 h-5" />
          {t("calc.back")}
        </button>
        <h1 className="text-4xl font-bold mb-2 bg-gradient-to-r from-blue-400 to-cyan-400 bg-clip-text text-transparent">
          {t("calc.title")}
        </h1>
        <p className="text-slate-300">
          {t("calc.designed_by")}
        </p>
      </div>

      {/* Main Content */}
      <div className="max-w-4xl mx-auto">
        <Card className="bg-slate-800 border-slate-700 p-8">
          {/* Language Selector */}
          <div className="mb-8 flex gap-4">
            <button
              onClick={() => setLanguage("ar")}
              className={`px-6 py-2 rounded-lg font-semibold transition-colors ${
                language === "ar"
                  ? "bg-blue-500 text-white"
                  : "bg-slate-700 text-slate-300 hover:bg-slate-600"
              }`}
            >
              {t("calc.arabic")}
            </button>
            <button
              onClick={() => setLanguage("en")}
              className={`px-6 py-2 rounded-lg font-semibold transition-colors ${
                language === "en"
                  ? "bg-blue-500 text-white"
                  : "bg-slate-700 text-slate-300 hover:bg-slate-600"
              }`}
            >
              {t("calc.english")}
            </button>
          </div>

          {/* Calculator Form */}
          <div className="space-y-6">
            {/* Fertilizer Selection */}
            <div>
              <label className="block text-lg font-semibold mb-3">
                {t("calc.select_fertilizer")}
              </label>
              <select
                value={selectedFertilizer}
                onChange={(e) => setSelectedFertilizer(e.target.value)}
                className="w-full bg-slate-700 border border-slate-600 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-cyan-400"
              >
                {FERTILIZERS_DATA.map((fert) => (
                  <option key={fert.en} value={fert.en}>
                    {language === "ar" ? fert.ar : fert.en}
                  </option>
                ))}
              </select>
            </div>

            {/* Units Input */}
            <div>
              <label className="block text-lg font-semibold mb-3">
                {t("calc.enter_units")}
              </label>
              <input
                type="number"
                value={units}
                onChange={(e) => setUnits(e.target.value === "" ? "" : parseFloat(e.target.value))}
                placeholder={language === "ar" ? "مثال: 10" : "Example: 10"}
                className="w-full bg-slate-700 border border-slate-600 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-cyan-400"
              />
            </div>

            {/* Calculate Button */}
            <Button
              onClick={calculate}
              className="w-full bg-gradient-to-r from-blue-500 to-cyan-500 hover:from-blue-600 hover:to-cyan-600 text-white font-bold py-3 text-lg"
            >
              {t("calc.calculate")}
            </Button>

            {/* Result */}
            {result && (
              <div className="bg-gradient-to-r from-green-500/20 to-emerald-500/20 border border-green-400/50 rounded-lg p-6">
                <p className="text-lg font-semibold text-green-300">{result}</p>
              </div>
            )}

            {/* Export Buttons */}
            {result && (
              <div className="grid grid-cols-3 gap-4">
                <Button
                  onClick={downloadCSV}
                  variant="outline"
                  className="border-blue-400 text-blue-400 hover:bg-blue-400/10"
                >
                  {t("calc.export_csv")}
                </Button>
                <Button
                  onClick={downloadExcel}
                  variant="outline"
                  className="border-blue-400 text-blue-400 hover:bg-blue-400/10"
                >
                  {t("calc.export_excel")}
                </Button>
                <Button
                  onClick={() => window.print()}
                  variant="outline"
                  className="border-green-400 text-green-400 hover:bg-green-400/10"
                >
                  {t("calc.print")}
                </Button>
              </div>
            )}
          </div>
        </Card>

        {/* Footer */}
        <div className="text-center mt-12 text-slate-400">
          <p>{t("footer.copyright")}</p>
        </div>
      </div>
    </div>
  );
}
